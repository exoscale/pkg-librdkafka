# Test librdkafka RPMs using docker

After building the RPMs (see README.md in parent directory) test
the RPMs on the supported CentOS/RHEL versions using:

    $ packaging/rpm/tests/test-on-docker.sh


